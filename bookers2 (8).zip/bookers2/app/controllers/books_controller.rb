class BooksController < ApplicationController
  # before_action :set_book, only: [:edit, :update, :destroy]
  
  def index
    @user = current_user
    @book = Book.new
    @books = Book.all
  end

  def show
    @books = Book.find(params[:id])
    # (params[:id])はURLの末尾の数字のことをIDとして指定している
    @user = User.find(@books.user_id)
    @book = Book.new
  end

  def create
    @user = User.find(current_user.id)
    # (current_user.id)ではなく（params[:id]）だと本のIDでuserを探してしまうことになる
    @book = Book.new(book_params)
    @book.user_id = current_user.id
    # これ↑ってこのままじゃ意味を成してない？
    # @user.user_id = current_user.idだったら意味を成してない
    # ==じゃなければ意味を成していない気がする
    if @book.save
      flash[:notice] = 'You have created book successfully.'
      redirect_to book_path(@book.id)
    else
      @books = Book.all
      
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])
    @user = User.find(@book.user_id)
    
    if @user.id != current_user.id
      redirect_to books_path
    end
    # ==にしないで !=にすることで一致しないときの操作だけを設定できる
    # 
    
  end

  def update
    @user = User.find(params[:id])
    @book = Book.find(params[:id])
    if @book.update(book_params)
      flash[:notice] = 'You have updated book successfully.'
      redirect_to book_path(@book)
    else
      render :edit
    end
  end

  def destroy
    @user = User.find(params[:id])
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path(@book)
  end
  
  private
  
  # def set_book
  #   @book = @user.books.find(params[:id])
  # end
  
  def book_params
    params.require(:book).permit(:title, :body)
  end
end
