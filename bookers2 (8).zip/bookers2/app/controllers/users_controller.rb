class UsersController < ApplicationController
  def index
    @user = current_user
    @users = User.all
    @book = Book.new
  end

  def show
    @user = User.find(params[:id])
    @book = Book.new
    @books = @user.books
  end

  def edit
    @user = User.find(params[:id])
    
    if @user.id != current_user.id
      redirect_to user_path(current_user.id)
      # リダイレクトするのは編集をしようとした誰かの編集画面ではなくて
      # ログインしているユーザーの編集画面
    end
    
  end

  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      flash[:notice] = 'You have updated user successfully.'
      redirect_to user_path(@user.id)
    else
      render :edit
    end
  end
  
  private
  # protected?
  def user_params
    params.require(:user).permit(:name, :profile_image, :introduction)
  end
end
# Strong params のpermit（）の中の値を設定しないと思った通りに変更されない
# 今回は:introduction抜けてて困った