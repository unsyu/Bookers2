# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'f22b4b71278a3954acbbe694c8d231f48c00d1f6e7278f7b622647011da082f18daa297b6078578b4457b2698984d7cc783e11d6b0f33db85d9c9c61d3ccd845'